// Function to fetch toilet status from ESP8266
function getToiletStatus() {
    fetch('/')
        .then(response => response.text())
        .then(data => {
            // Extracting status from HTML response
            const status = data.match(/<h1>Toilet Status: (.*?)<\/h1>/)[1];
            document.getElementById('status').innerText = `Toilet Status: ${status}`;
            // Change background color based on toilet status
            if (status === 'Open') {
                cycleBackgroundColor(['#b3ffb3', '#99ddff', '#ffc0cb']); // Green, Light Blue, Pink
            } else {
                cycleBackgroundColor(['#ff9999', '#ffcc99', '#ffff99']); // Red, Light Orange, Yellow
            }
        })
        .catch(error => {
            console.error('Error fetching toilet status:', error);
            document.getElementById('status').innerText = 'Error fetching status';
        });
}

// Function to cycle through background colors
function cycleBackgroundColor(colors) {
    let currentIndex = 0;
    setInterval(() => {
        document.body.style.backgroundColor = colors[currentIndex];
        currentIndex = (currentIndex + 1) % colors.length;
    }, 3000); // Change color every 3 seconds
}

// Update toilet status on page load
getToiletStatus();

// Periodically update toilet status
setInterval(getToiletStatus, 5000); // Update every 5 seconds
